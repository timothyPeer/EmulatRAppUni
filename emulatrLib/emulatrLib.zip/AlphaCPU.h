#ifndef AlphaCPU_h__
#define AlphaCPU_h__



// ============================================================================
// AlphaCPU.h - CPU Orchestrator (Inline-Only)
// ============================================================================
// Orchestrates instruction execution through AlphaPipeline.
// Responsibilities:
//   - Run loop: fetch -> pipeline -> retire -> check faults
//   - Fault/interrupt eligibility (not in PAL mode)
//   - Event delivery via FaultDispatcher -> PAL vector entry
//   - CALL_PAL treated as instruction grain with PAL mode transition
// ============================================================================
#include "../MBoxLib_EV6/MBoxBase.h"
#include <QObject>
#include <QtGlobal>
#include <QThread>
#include <QAtomicInteger>
#include <QScopedPointer>
#include "AlphaProcessorContext.h"
#include "../configLib/global_EmulatorSettings.h"

// Forward declarations
struct IFaultSink;

#include "../emulatrLib/global_SMPManager.h"
#include "../coreLib/types_core.h"
#include "../palLib_EV6/PalVectorId_refined.h"
#include "../palLib_EV6/Global_PALVectorTable.h"
#include "../coreLib/global_IRQController.h"
#include "../faultLib/GlobalFaultDispatcherBank.h"
#include "../pteLib/Ev6SiliconTLB_Singleton.h"
#include "../faultLib/IFaultSink.h"
#include "../coreLib/IRQController.h"
#include "../coreLib/BranchPredictionStats.h"
#include "../coreLib/LoggingMacros.h"
#include "../IBoxLib/iBoxBase.h"
#include "../faultLib/global_faultDispatcher.h"
#include "../palLib_EV6/PalArgumentPack_str.h"
#include "../palLib_EV6/PalVectorResolver_EV6.h"
#include "../palLib_EV6/PalVectorTable_final.h"

#include "../deviceLib/SRMConsole.h"
#include <memory>
#include "../deviceLib/global_SRMEnvStore.h"
#include "../palLib_EV6/Pal_Service.h"


class alignas(8) AlphaCPU final : public QObject
{
	Q_OBJECT

	enum class PendingEventType {
		None,
		CodeModification,
		CacheInvalidation,

	};

static std::unique_ptr<SRMConsole> s_srmConsole;  // Only on CPU0

struct PendingEvent_cpuLocal {
	PendingEventType type{ PendingEventType::None };
	quint64 startPC{ 0 };
	quint64 endPC{ 0 };
	quint64 eventData{ 0 };

	void clear() noexcept { type = PendingEventType::None; }
	bool isPending() const noexcept { return type != PendingEventType::None; }
};

PendingEvent_cpuLocal m_pendingEvent;

public:
	explicit AlphaCPU(CPUIdType cpuId, 	CPUFamily family, AlphaProcessorContext* ctx, IFaultSink* faultSink, QObject* parent = nullptr) noexcept
		: QObject(parent)
		, m_cpuId(cpuId)
		, m_family(family)
		, m_ctx(ctx)
		, m_faultSink(faultSink)
		, m_irqController(&global_IRQController())
	{
		// Context must exist
		if (!m_ctx) {
			CRITICAL_LOG(QString("AlphaCPU: null context"));
			return;
		}
	}

	~AlphaCPU() override
	{

	}

	void stop() noexcept {

	}
	void pause() noexcept {
	}

	void start() noexcept {

	}

	AXP_HOT AXP_ALWAYS_INLINE void resume() noexcept {

	}


	void enterSRMConsole() noexcept {
		if (m_cpuId != 0) {
			//  Non-primary CPUs must halt and wait
			haltUntilSRMExit();
			return;
		}

		auto settings = global_EmulatorSettings();
		auto envStore = global_SRMEnvStore();
		//  Only CPU0 runs SRM console
		if (!s_srmConsole) {
			s_srmConsole = std::make_unique<SRMConsole>(settings, envStore);
			s_srmConsole->initialize(m_ctx);
		}

		s_srmConsole->start();
		while (s_srmConsole->isRunning()) {
			s_srmConsole->step();
		}
	}

	void handleCodeModification(quint64 startPC, quint64 endPC) noexcept;
	const PendingEvent_cpuLocal& getPendingEvent() const noexcept { return m_pendingEvent; }
	void clearPendingEvent() noexcept { m_pendingEvent.clear(); }

	AlphaProcessorContext& context() noexcept { return *m_ctx; }
	const AlphaProcessorContext& context() const noexcept { return *m_ctx; }
	AlphaProcessorContext* contextPtr() noexcept { return m_ctx; }

	

	inline CPUIdType cpuId() const noexcept { return m_cpuId; }
	inline CPUFamily family() const noexcept { return m_family; }
	inline PalService* palService() noexcept { return m_palService; }

	void reset()
	{
		// Reset branch predictor to default
		CBox* cbox = m_iBox->getCBox();
		cbox->getBranchPredictor().clear();// TODO - Check resetBranchPredictor();
	}

	bool isInPalMode() const noexcept { return m_iBox->isInPalMode(); }

	// ========================================================================
	// Main Execution Loop
	// ========================================================================
	AXP_HOT AXP_ALWAYS_INLINE void runOneInstruction() {
		// ========================================================================
		// 1. Check PAL mode (from Hot64 cache - already optimized)
		// ========================================================================
		auto& hot = globalIPRHot64(m_cpuId);  // Bind once
		const bool inPalMode = hot.isInPalMode();

		// ========================================================================
		// 2. Fast pre-check: any async events pending? (CBox mailbox)
		// ========================================================================
		if (!inPalMode) {
			auto& cbox = globalIPRCBox(m_cpuId);  // Isolated cache line

			// Fast atomic read - no function call
			if (cbox.hasAnyPendingEvent()) {
				// Only call heavy poll() if mailbox indicates work
				auto& irqCtrl = global_IRQController();
				irqCtrl.poll(m_cpuId, m_faultSink);

				if (m_faultSink->eventPending()) {
					deliverPendingEvent();
					m_iBox->flush();
					return;
				}
			}
		}

		// ========================================================================
		// 3. Execute pipeline (hot path - no polling overhead)
		// ========================================================================
		m_iBox->step();

		// ========================================================================
		// 4. Post-execution check (only if CBox indicates pending)
		// ========================================================================
		if (!inPalMode) {
			auto& cbox = globalIPRCBox(m_cpuId);
			if (cbox.hasAnyPendingEvent()) {
				deliverPendingEvent();
				m_iBox->getPipeLine()->flush();
				return;
			}
		}

		// ========================================================================
		// 5. Fetch (no change)
		// ========================================================================
		if (!m_iBox->getPipeLine()->isFrontendStalled()) {
			FetchResult fetchResult;
			if (m_iBox->fetchAndDecode(fetchResult)) {
				m_iBox->getPipeLine()->supplyFetchResult(fetchResult);
			}
		}
	}



	void haltUntilSRMExit() noexcept {
		INFO_LOG(QString("CPU %1 halting until SRM console exits").arg(m_cpuId));

		// Set CPU state to halted
		global_SMPManager().setCPUHalted(m_cpuId, true);

	

		// Wait for SRM console to finish (spin-wait or event-based)
		while (s_srmConsole && s_srmConsole->isRunning()) {
			// Yield CPU time while waiting
			QThread::msleep(10);  // 10ms sleep

			// Check for interrupts that might wake us
			if (checkForWakeupInterrupts()) {
				break;
			}
		}

		// Resume normal execution
	/*	m_cpuState = CPUState::Running;*/
		global_SMPManager().setCPUHalted(m_cpuId, false);
		INFO_LOG(QString("CPU %1 resuming after SRM console exit").arg(m_cpuId));
	}
	bool checkForWakeupInterrupts() noexcept {
		// Check using your new class-based system
		if (global_IRQController().hasPendingClass(m_cpuId, InterruptClass::IPI)) {
			DEBUG_LOG(QString("CPU %1 woken by IPI").arg(m_cpuId));
			return true;
		}

		if (global_IRQController().hasPendingClass(m_cpuId, InterruptClass::Timer)) {
			DEBUG_LOG(QString("CPU %1 woken by timer").arg(m_cpuId));
			return true;
		}

		return false;
	}
	// ========================================================================
	// Handle TLB Shootdown IPI
	// ========================================================================
	AXP_ALWAYS_INLINE void handleTLBShootdown(
		quint32 vaHigh,
		quint32 vaLow,
		quint64 asnRealm) noexcept
	{
		// Reconstruct VA from parameters
		const quint64 va = (static_cast<quint64>(vaHigh) << 32) | vaLow;

		// Extract ASN and realm
		const ASNType asn = static_cast<ASNType>(asnRealm >> 32);
		const Realm realm = static_cast<Realm>(asnRealm & 0xFF);

		// Invalidate TLB entry
		globalEv6SPAM().invalidateDTBEntry(m_cpuId, va, asn);
		globalEv6SPAM().invalidateITBEntry(m_cpuId, va, asn);

		DEBUG_LOG(QString("CPU%1: TLB shootdown VA=0x%2 ASN=%3 realm=%4")
			.arg(m_cpuId)
			.arg(va, 16, 16, QChar('0'))
			.arg(asn)
			.arg(realm == Realm::D ? "D" : "I"));
	}

	

	// ========================================================================
	// Handle Cache Coherency IPI
	// ========================================================================
	AXP_ALWAYS_INLINE void handleCacheCoherency(
		quint32 p1,
		quint32 p2,
		quint64 p3) noexcept
	{
		// Flush cache line, invalidate cache, etc.
		// Implementation depends on cache model
		DEBUG_LOG(QString("CPU%1: Cache coherency IPI").arg(m_cpuId));
	}

	// ========================================================================
	// Handle Barrier Synchronization IPI
	// ========================================================================
	AXP_ALWAYS_INLINE void handleBarrierSync(
		quint32 barrierIdHigh,
		quint32 barrierIdLow,
		quint64 flags) noexcept
	{
		const quint64 barrierId = (static_cast<quint64>(barrierIdHigh) << 32) | barrierIdLow;

		// Signal arrival at barrier
		// Implementation depends on barrier model
		DEBUG_LOG(QString("CPU%1: Barrier sync barrier=%2")
			.arg(m_cpuId)
			.arg(barrierId));
	}

	// ========================================================================
	// Handle Custom IPI
	// ========================================================================
	
	void checkInterrupts() {
		quint32 vector;
		quint8 ipl;

		
		// Query IRQController for deliverable interrupt
		if (m_irqController->queryPendingInterrupt(m_cpuId, getIPL_Active(m_cpuId),
			vector, ipl)) {
			// Interrupt is deliverable - inject pending event
			raisePendingEvent(PendingEventKind::Interrupt, vector, ipl);
		}
	}

	// In AlphaCPU.cpp or wherever you handle interrupt injection

	void raisePendingEvent(PendingEventKind type, quint32 vector, quint8 ipl)
	{
		if (vector == IPI_VECTOR) {
			// ================================================================
			// IPI INTERRUPT - Build PAL argument pack
			// ================================================================

			// Get pointer to this CPU's mailbox
			CPUIRQState &cpuState = m_irqController->getCPUState(m_cpuId);
			IpiMailbox* mailbox = &cpuState.ipiMailbox;

			// Snapshot reason mask (PAL will fetch-and-clear)
			quint32 reasonSnapshot = mailbox->peek();

			// Build PAL argument pack
			PalArgumentPack args;
			args.a0 = reinterpret_cast<quint64>(mailbox);  // Mailbox pointer
			args.a1 = reasonSnapshot;                       // Reason bitmask
			args.a2 = vector;                               // Vector number
			args.a3 = 0;                                    // Reserved
			args.a4 = 0;                                    // Reserved
			args.a5 = 0;                                    // Reserved

			// Save exception PC (current PC or next PC depending on timing)
			quint64 exceptionPC = getPC_Active(m_cpuId);

			// Enter PAL IPI handler
			m_palService->enterPALVector(context(),
				PalVectorId::IPI_INTERRUPT,
				exceptionPC,
				args
			);

			DEBUG_LOG(QString("CPU%1: IPI interrupt taken, reasons=0x%2")
				.arg(m_cpuId)
				.arg(reasonSnapshot, 8, 16, QChar('0')));
		}
		else {
			// ================================================================
			// OTHER INTERRUPTS - Use existing logic
			// ================================================================

			PalArgumentPack args;
			args.a0 = vector;  // Interrupt vector
			args.a1 = ipl;     // Interrupt priority level
			// ... other args as needed ...

			m_palService->enterPALVector(context(),	PalVectorId::INTERRUPT,  // Or appropriate vector ID
				getPC_Active(m_cpuId),
				args
			);
		}
	}


	// ========================================================================
	// Deliver Pending Event to PAL Vector
	// ========================================================================
	AXP_ALWAYS_INLINE void deliverPendingEvent() noexcept
	{
		// 1. Get pending event
		const PendingEvent ev = m_faultSink->getPendingEvents();

		// 2. Clear event before entering PAL (prevents re-entry)
		m_faultSink->clearPendingEvents();

		// 3. Resolve PAL vector ID from event
		PalVectorId vectorId = resolvePalVector(ev);

		if (vectorId == PalVectorId::INVALID) {
			WARN_LOG(QString("CPU%1: Invalid PAL vector for event").arg(m_cpuId));
			return;
		}

		// 4. Lookup vector entry in PAL table
		auto& palTable = global_PalVectorTable();
		const PalVectorEntry* entry = palTable.lookup(vectorId);

		if (!entry || entry->entryPC == 0xDEADBEEFDEADBEEF) {
			CRITICAL_LOG(QString("CPU%1: Unimplemented PAL vector %2")
				.arg(m_cpuId)
				.arg(static_cast<int>(vectorId)));
			return;
		}

		// 5. Populate PAL arguments according to Alpha PAL convention
		PalArgumentPack argPack;

		switch (ev.exceptionClass) {
		// ====================================================================
		// TLB Miss Exceptions
		// ====================================================================
		case ExceptionClass_EV6::Dtb_miss_single:
			// Single DTB miss - normal case
			argPack.a0 = ev.faultVA;                    // R16 = faulting VA
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR (fault reason)
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

		case ExceptionClass_EV6::Dtb_miss_double_4:
			// Double DTB miss - recursive miss during page table walk
			argPack.a0 = ev.faultVA;                    // R16 = primary faulting VA
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = ev.dtbFaultVA;                 // R19 = secondary VA (double miss)
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

		case ExceptionClass_EV6::ItbMiss:
			// Instruction TLB miss
			argPack.a0 = ev.faultVA;                    // R16 = faulting VA (= PC for ITB)
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC (same as a0)
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Data Faults (ACV, FOW, FOR)
			// ====================================================================
		case ExceptionClass_EV6::Dfault:
			// Data fault - access violation, fault-on-write/read
			argPack.a0 = ev.faultVA;                    // R16 = faulting VA
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR (includes fault type)
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = ev.mmFaultReason;              // R19 = detailed fault reason
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

		case ExceptionClass_EV6::ItbAcv:
			// Instruction access violation
			argPack.a0 = ev.faultVA;                    // R16 = faulting VA
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Alignment Fault
			// ====================================================================
		case ExceptionClass_EV6::Unalign:
			// Unaligned memory access
			argPack.a0 = ev.faultVA;                    // R16 = unaligned VA
			argPack.a1 = ev.opcode;                     // R17 = instruction opcode
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = ev.destReg;                    // R19 = destination register (for loads)
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Illegal Instruction
			// ====================================================================
		case ExceptionClass_EV6::OpcDec:
			// Illegal/reserved opcode
			argPack.a0 = 0;                             // R16 = reserved
			argPack.a1 = ev.opcode;                     // R17 = illegal instruction word
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Arithmetic Trap
			// ====================================================================
		case ExceptionClass_EV6::Arithmetic:
			// Integer overflow or floating-point trap
			argPack.a0 = ev.exc_Sum;                    // R16 = exception summary (EXC_SUM)
			argPack.a1 = ev.exc_Mask;                   // R17 = trap register mask
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Floating-Point Disabled
			// ====================================================================
		case ExceptionClass_EV6::Fen:
			// Floating-point instruction with FP disabled
			argPack.a0 = 0;                             // R16 = reserved
			argPack.a1 = 0;                             // R17 = reserved
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Interrupts
			// ====================================================================
		case ExceptionClass_EV6::Interrupt:
			// Hardware or software interrupt
			argPack.a0 = ev.pendingEvent_Info.irqSummary;   // R16 = interrupt summary
			argPack.a1 = ev.pendingEvent_Info.irqVector;    // R17 = interrupt vector
			argPack.a2 = ev.faultPC;                        // R18 = interrupted PC
			argPack.a3 = ev.deviceInterruptVector;          // R19 = device interrupt vector
			argPack.a4 = ev.hwIPL;                          // R20 = hardware IPL
			argPack.a5 = 0;                                 // R21 = reserved
			break;

			// ====================================================================
			// Machine Check
			// ====================================================================
		case ExceptionClass_EV6::MachineCheck:
			// Hardware error or machine check
			argPack.a0 = ev.pendingEvent_Info.mchkSummary;  // R16 = error summary
			argPack.a1 = ev.pendingEvent_Info.logoutFrame;  // R17 = logout frame pointer
			argPack.a2 = ev.faultPC;                        // R18 = interrupted PC
			argPack.a3 = ev.mchkCode;                       // R19 = machine check code
			argPack.a4 = ev.mchkAddr;                       // R20 = error physical address
			argPack.a5 = 0;                                 // R21 = reserved
			break;

			// ====================================================================
			// System Reset
			// ====================================================================
		case ExceptionClass_EV6::Reset:
			// System reset or power-on
			argPack.a0 = 0;                             // R16 = reserved
			argPack.a1 = 0;                             // R17 = reserved
			argPack.a2 = 0;                             // R18 = reserved
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// CALL_PAL (Unprivileged/Privileged)
			// ====================================================================
		case ExceptionClass_EV6::CallPal:
			// PAL call - arguments passed through from user code
			argPack.a0 = ev.palR16;                     // R16 = user arg 0
			argPack.a1 = ev.palR17;                     // R17 = user arg 1
			argPack.a2 = ev.faultPC;                    // R18 = return PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// D-Stream Error (Memory System Error)
			// ====================================================================
		case ExceptionClass_EV6::DStream:
			// Memory system error (cache parity, bus error, etc.)
			argPack.a0 = ev.faultVA;                    // R16 = faulting VA
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = ev.pendingEvent_Info.physicalAddress;  // R19 = physical address
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// MT_FPCR (Move To FPCR)
			// ====================================================================
		case ExceptionClass_EV6::MT_FPCR:
			// MT_FPCR instruction (if implemented as exception)
			argPack.a0 = 0;                             // R16 = reserved
			argPack.a1 = 0;                             // R17 = reserved
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = 0;                             // R19 = reserved
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved
			break;

			// ====================================================================
			// Default/Unknown Exception
			// ====================================================================
		default:
			// Unknown or unhandled exception - provide generic fault info
			argPack.a0 = ev.faultVA;                    // R16 = faulting VA (if applicable)
			argPack.a1 = buildMMCSR(ev);                // R17 = MMCSR
			argPack.a2 = ev.faultPC;                    // R18 = faulting PC
			argPack.a3 = static_cast<quint64>(ev.exceptionClass);  // R19 = exception class
			argPack.a4 = 0;                             // R20 = reserved
			argPack.a5 = 0;                             // R21 = reserved

			WARN_LOG(QString("CPU%1: Unhandled exception class %2")
				.arg(m_cpuId)
				.arg(static_cast<int>(ev.exceptionClass)));
			break;
		}

		// 6. Set PAL mode state
		argPack.ipl = 7;  // Set IPL to 7 (block all maskable interrupts during PAL)
		argPack.PalOffset = const_cast<PalVectorEntry*>(entry);

		// 7. Enter PAL vector (saves state, sets PAL mode, transfers control)
		m_palService->enterPALVector(context(),
			vectorId,
			ev.faultPC,
			argPack
		);
	}
	
	// ========================================================================
	// Deliver Pending Event to PAL Vector
	// ========================================================================

	/*
	 The dispatcher that routes to the right resolver based on ev.kind:
	*/
	AXP_ALWAYS_INLINE PalVectorId resolvePalVector(const PendingEvent& ev) noexcept
	{
		switch (ev.kind) {
		case PendingEventKind::Exception:
			return PalVectorResolver_EV6::resolveExceptionVector(ev.exceptionClass);  //  Delegates here

		case PendingEventKind::Interrupt:
			return PalVectorId::INTERRUPT;

		case PendingEventKind::MachineCheck:
			return PalVectorId::MCHK;

		case PendingEventKind::PalCall:
			return PalVectorResolver_EV6::resolveCallPalVector(ev.palFunction);

		default:
			return PalVectorId::INVALID;
		}
	}

	// ========================================================================
	// Resolve Event -> PAL Vector ID
	// ========================================================================
	static inline PalVectorId resolveExceptionVector(PendingEvent ev) noexcept
	{
		ExceptionClass_EV6 excClass = ev.exceptionClass;
		switch (excClass)
		{
		case ExceptionClass_EV6::Reset:
			return PalVectorId::RESET;          // 0x0000
		case ExceptionClass_EV6::MachineCheck:
			return PalVectorId::MCHK;           // 0x0020
		case ExceptionClass_EV6::Arithmetic:
			return PalVectorId::ARITH;          // 0x0060
		case ExceptionClass_EV6::Interrupt:
			return PalVectorId::INTERRUPT;      // 0x00E0
		case ExceptionClass_EV6::ItbMiss:
			return PalVectorId::ITB_MISS;       // 0x03E0
		case ExceptionClass_EV6::ItbAcv:
			return PalVectorId::IACCVIO;        // 0x07E0
		case ExceptionClass_EV6::OpcDec:
			return PalVectorId::OPCDEC;         // 0x13E0
		case ExceptionClass_EV6::Fen:
			return PalVectorId::FEN;            // 0x17E0

			// ? ADD THESE MISSING CASES:
		case ExceptionClass_EV6::Dtb_miss_single:
			return PalVectorId::DTB_MISS_SINGLE;  // 0x01E0

		case ExceptionClass_EV6::Dtb_miss_double_4:
			return PalVectorId::DTB_MISS_DOUBLE;  // 0x02E0

		case ExceptionClass_EV6::Dfault:
			return PalVectorId::DFAULT;           // 0x05E0

		case ExceptionClass_EV6::Unalign:
			return PalVectorId::UNALIGN;          // 0x11E0

		case ExceptionClass_EV6::DStream:
			// D-stream faults (memory system errors)
			return PalVectorId::DFAULT;           // Usually mapped to DFAULT

		case ExceptionClass_EV6::CallPal:
			// CALL_PAL should not reach here - handled as grain
			// If it does, extract function from event
			return PalVectorResolver_EV6::resolveCallPalVector(
				static_cast<quint8>(ev.palFunction)
			);

		default:
			// Unknown exception - fail safe to machine check
			return PalVectorId::MCHK;
		}
	}

	// ========================================================================
	// Commit Staged Architectural Updates (Post-Retirement)
	// ========================================================================
	AXP_HOT	AXP_ALWAYS_INLINE void commitStagedUpdates() {
	// NO-OP: PAL owns all TLB insertions
	// Staged PTEs are optimization hints only
	// They are discarded on pipeline flush
	// PAL performs actual TLB insertion after page table walk
	}

private:
	CPUIdType  m_cpuId{ 0 };
	CPUFamily  m_family{};

	AlphaProcessorContext* m_ctx{  };
	IFaultSink* m_faultSink;
	IRQController* m_irqController{};
	QScopedPointer<IBox> m_iBox;
	PalService* m_palService{ nullptr };


	QAtomicInteger<bool> m_running{ false };


#pragma region Staged DTB/ITB Update

	inline void clearStagedDTBUpdate() noexcept {

	}
	inline void clearStagedITBUpdate() noexcept {

	}

#pragma endregion Staged DTB/ITB Update

#pragma region PALmode Accessors

	PalService* getPalService() noexcept {	return m_palService; }
	void finalizePalExit() noexcept {

	}
	void prepareForPalEntry() noexcept {

	}


#pragma endregion PALmode Accessors

#pragma region PAL Halt
	void haltCPU() noexcept {
	}
	void setHaltCode(quint8 bip_rc_struct_code) noexcept {

	}
	void setHalted(bool bState) noexcept {

	}
	void notifyHalt() noexcept {

	}
#pragma endregion PAL Halt

};


#endif // AlphaCPU_h__
