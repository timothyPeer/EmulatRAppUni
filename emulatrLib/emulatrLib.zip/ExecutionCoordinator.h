// ============================================================================
// ExecutionCoordinator.h
// ============================================================================
// Execution resource management and run-state control
// Single Responsibility: Manage CPU worker threads and execution policy
// ============================================================================

#ifndef EXECUTIONCOORDINATOR_H
#define EXECUTIONCOORDINATOR_H

#include <QtCore/QObject>
#include <QtCore/QThread>
#include <array>
#include <memory>
#include <atomic>
#include "../coreLib/types_core.h"
#include "CPUStateManager.h"
#include "IPIManager.h"
#include "../coreLib/Axp_Attributes_core.h"
#include "../coreLib/global_IRQController.h"
#include "../memoryLib/global_MemoryBarrierCoordinator.h"
#include "../memoryLib/MemoryBarrierCoordinator.h"

// Forward declarations
class AlphaCPU;

// ============================================================================
// EXECUTION COORDINATOR - Manages CPU worker threads and execution state
// ============================================================================

class ExecutionCoordinator : public QObject {
	Q_OBJECT

public:
	explicit ExecutionCoordinator(int cpuCount, QObject* parent = nullptr);
	~ExecutionCoordinator() override;

	// Non-copyable
	Q_DISABLE_COPY(ExecutionCoordinator)

	// ========================================================================
	// Execution Control
	// ========================================================================

		void start();
	void pause();
	void stop();
	void reset();

	// Per-CPU control

	AXP_HOT AXP_ALWAYS_INLINE void pauseCPU(CPUIdType cpuId);

	AXP_HOT AXP_ALWAYS_INLINE void resumeCPU(CPUIdType cpuId);

	AXP_HOT AXP_ALWAYS_INLINE  void stopCPU(CPUIdType cpuId);

	// ========================================================================
	// Execution State Queries (delegates to CPUStateManager)
	// ========================================================================



	bool isQuiescent(CPUIdType cpuId) const noexcept {
		return m_cpuStateManager.isQuiescent(cpuId);
	}

	AXP_HOT AXP_ALWAYS_INLINE QString getAllIPIStatistics() const {
		return m_ipiManager.getAllIPIStatistics();
	}

	AXP_HOT AXP_ALWAYS_INLINE QString getAllCPUStatesString() const {
		// TODO
		return QString();
	}

	AXP_HOT AXP_ALWAYS_INLINE QString getCPUStateString(CPUIdType cpuId) const noexcept {
		return m_cpuStateManager.getCPUStateString(cpuId);
	}


	// ====================================================================
	// CPU STATE MANAGEMENT (delegates to CPUStateManager)
	// ====================================================================

	void setCPUHalted(CPUIdType cpuId, bool halted) noexcept { m_cpuStateManager.setCPUHalted(cpuId, halted); }
	bool isCPUHalted(CPUIdType cpuId) const noexcept { return m_cpuStateManager.isCPUHalted(cpuId); }
	void notifyCPUHalted(CPUIdType cpuId, quint32 haltCode) noexcept { m_cpuStateManager.notifyCPUHalted(cpuId, haltCode); }

	void setCPUWaiting(CPUIdType cpuId, bool waiting) noexcept { m_cpuStateManager.setCPUWaiting(cpuId, waiting); }
	bool isCPUWaiting(CPUIdType cpuId) const noexcept { return m_cpuStateManager.isCPUWaiting(cpuId); }

	void requestQuiescence(CPUIdType cpuId) noexcept { m_cpuStateManager.requestQuiescence(cpuId); }
	void waitForQuiescence(CPUIdType cpuId) noexcept { m_cpuStateManager.waitForQuiescence(cpuId); }
	void signalQuiescence(CPUIdType cpuId) noexcept { m_cpuStateManager.signalQuiescence(cpuId); }

	void registerPendingStore(CPUIdType cpuId) noexcept { m_cpuStateManager.registerPendingStore(cpuId); }
	void completePendingStore(CPUIdType cpuId) noexcept { m_cpuStateManager.completePendingStore(cpuId); }
	quint32 getPendingStoreCount(CPUIdType cpuId) const noexcept { return m_cpuStateManager.getPendingStoreCount(cpuId); }

	quint64 getActiveCPUMask() const noexcept { return m_cpuStateManager.getActiveCPUMask(); }
	quint16 getActiveCPUCount() const noexcept { return m_cpuStateManager.getActiveCPUCount(); }

	void resetCPU(CPUIdType cpuId) noexcept { m_cpuStateManager.resetCPU(cpuId); }
	// ========================================================================
	// IPI Management (execution policy)
	// ========================================================================

	bool requestReschedule(CPUIdType targetCpu) noexcept;
	bool requestTLBShootdown(CPUIdType targetCpu, quint64 va, quint8 asn, quint8 sizeClass) noexcept;
	quint16 broadcastReschedule(CPUIdType sourceCpu) noexcept;

	AXP_HOT AXP_ALWAYS_INLINE bool requestMemoryBarrier(CPUIdType cpuId) noexcept {
		if (!isValidCPU(cpuId)) {
			return false;
		}

		// Get active CPU count for barrier coordination
		quint16 activeCpuCount = getActiveCPUCount();

		// Get global singletons
		auto& mbCoord = global_MemoryBarrierCoordinator();
		IRQController& irqCtrl = global_IRQController();

		// Request global memory barrier (sends IPIs to all other CPUs)
		mbCoord.requestGlobalMemoryBarrier(cpuId, activeCpuCount, &irqCtrl);

		DEBUG_LOG(QString("CPU %1: Requested memory barrier (active CPUs: %2)")
			.arg(cpuId).arg(activeCpuCount));

		return true;
	}

	AXP_HOT AXP_ALWAYS_INLINE quint16 broadcastTLBShootdown(const TLBShootdownMessage& tlbmsg, quint16 cpuCount) noexcept {
		if (!isValidCPU(tlbmsg.sourceCpu)) {
			return 0;
		}

		IRQController& irqCtrl = global_IRQController();
		quint16 sentCount = 0;

		// Broadcast to all CPUs except the source
		for (CPUIdType targetCpu = 0; targetCpu < cpuCount; ++targetCpu) {
			if (targetCpu == tlbmsg.sourceCpu) {
				continue;  // Don't send to self
			}

			// Send TLB shootdown IPI to each target CPU
			bool sent = m_ipiManager.requestTLBShootdown(
				targetCpu,
				tlbmsg.va,
				tlbmsg.asn,
				&irqCtrl
			);

			if (sent) {
				sentCount++;
			}
		}

		DEBUG_LOG(QString("CPU %1: Broadcast TLB shootdown VA=0x%2 ASN=%3 (sent to %4 CPUs)")
			.arg(tlbmsg.sourceCpu)
			.arg(tlbmsg.va, 16, 16, QChar('0'))
			.arg(tlbmsg.asn)
			.arg(sentCount));

		return sentCount;
	}
	
	AXP_HOT AXP_ALWAYS_INLINE bool sendCustomIPI(CPUIdType cpuId, IPIManager::IPIType ipiType, quint64 data) noexcept {
		if (!isValidCPU(cpuId)) {
			return false;
		}

		// Send custom IPI via IPIManager (already implemented correctly!)
		bool sent = m_ipiManager.sendCustomIPI(cpuId, ipiType, data, &global_IRQController());

		if (sent) {
			DEBUG_LOG(QString("Sent custom IPI type=%1 to CPU %2")
				.arg(static_cast<int>(ipiType)).arg(cpuId));
		}
		else {
			WARN_LOG(QString("Failed to send custom IPI to CPU %1").arg(cpuId));
		}

		return sent;
	}
	
	QString getIPIStatistics(CPUIdType cpuId) const noexcept {
		return m_ipiManager.getIPIStatistics(cpuId);
	}




	// ========================================================================
	// Memory Ordering (delegates to globals via SSC)
	// ========================================================================

	void requestGlobalMemoryBarrier(CPUIdType cpuId) noexcept;
	void waitForBarrierAcknowledge(CPUIdType cpuId) noexcept;
	void acknowledgeMemoryBarrier(CPUIdType cpuId) noexcept;
	bool isMemoryBarrierInProgress() const noexcept;

	void drainWriteBuffers(CPUIdType cpuId) noexcept;
	bool hasPendingWrites(CPUIdType cpuId) const noexcept;

	// ========================================================================
	// CPU Quiescence (delegates to CPUStateManager)
	// ========================================================================





	// ========================================================================
	// Diagnostics
	// ========================================================================

	bool isRunning() const noexcept { return m_systemRunning.load(); }
	int cpuCount() const noexcept { return m_cpuCount; }

	QString getSystemStatus() const noexcept;
	QString getCPUStatus(CPUIdType cpuId) const noexcept;

signals:
	void systemStarted();
	void systemPaused();
	void systemStopped();
	void cpuHalted(CPUIdType cpuId);
	void cpuError(CPUIdType cpuId, QString reason);

private slots:
	void onCPUHalted(CPUIdType cpuId);
	void onCPUError(CPUIdType cpuId, QString reason);

private:
	// ========================================================================
	// Execution Resources (OWNED by ExecutionCoordinator)
	// ========================================================================

	struct CPUWorker {
		std::unique_ptr<QThread> thread;
		std::unique_ptr<AlphaCPU> alphaCPU;
	};

	std::array<CPUWorker, MAX_CPUS> m_workers;
	int m_cpuCount;

	// ========================================================================
	// Execution State (NOT hardware state)
	// ========================================================================

	CPUStateManager m_cpuStateManager;  // Moved from SmpManager
	IPIManager m_ipiManager;             // Moved from SmpManager

	std::atomic<bool> m_systemRunning{ false };
	std::atomic<bool> m_systemPaused{ false };

	// ========================================================================
	// Private Helpers
	// ========================================================================

	void createWorkers();
	void destroyWorkers();

	bool isValidCPU(CPUIdType cpuId) const noexcept {
		return cpuId < static_cast<CPUIdType>(m_cpuCount);
	}
};

#endif // EXECUTIONCOORDINATOR_H