// ============================================================================
// ExecutionCoordinator.cpp
// ============================================================================

#include "ExecutionCoordinator.h"
#include "../cpuCoreLib/AlphaCPU.h"
#include "../coreLib/LoggingMacros.h"
#include "../memoryLib/global_guestMemory.h"
#include "../mmioLib/global_mmioManager.h"
#include "../coreLib/global_IRQController.h"
#include "../memoryLib/global_writeBufferManager.h"
#include "../memoryLib/global_MemoryBarrierCoordinator.h"
#include "../coreLib/types_core.h"
#include "../memoryLib/MemoryBarrierCoordinator.h"
#include "../coreLib/IRQController.h"
#include "../memoryLib/WriteBufferManager.h"

// ============================================================================
// CONSTRUCTOR / DESTRUCTOR
// ============================================================================

ExecutionCoordinator::ExecutionCoordinator(int cpuCount, QObject* parent)
	: QObject(parent)
	, m_cpuCount(cpuCount)
{
	Q_ASSERT(cpuCount > 0 && cpuCount <= MAX_CPUS);

	INFO_LOG(QString("ExecutionCoordinator: Initializing with %1 CPUs").arg(cpuCount));

	createWorkers();

	INFO_LOG("ExecutionCoordinator: Initialization complete");
}

ExecutionCoordinator::~ExecutionCoordinator()
{
	INFO_LOG("ExecutionCoordinator: Shutting down");

	stop();
	destroyWorkers();

	INFO_LOG("ExecutionCoordinator: Shutdown complete");
}

// ============================================================================
// WORKER CREATION / DESTRUCTION
// ============================================================================

void ExecutionCoordinator::createWorkers()
{
	INFO_LOG("ExecutionCoordinator: Creating CPU workers");

	for (int i = 0; i < m_cpuCount; ++i) {
		auto& worker = m_workers[i];

		// Create thread
		worker.thread = std::make_unique<QThread>();
		worker.thread->setObjectName(QString("CPU%1_Thread").arg(i));

		// Create AlphaCPU worker
		worker.alphaCPU = std::make_unique<AlphaCPU>(static_cast<CPUIdType>(i));

		// Move worker to thread (moveToThread pattern)
		worker.alphaCPU->moveToThread(worker.thread.get());

		// Connect thread lifecycle
		connect(worker.thread.get(), &QThread::started,
			worker.alphaCPU.get(), &AlphaCPU::executeLoop);

		connect(worker.thread.get(), &QThread::finished,
			worker.thread.get(), &QThread::deleteLater);

		// Connect worker signals
		connect(worker.alphaCPU.get(), &AlphaCPU::halted,
			this, &ExecutionCoordinator::onCPUHalted);

		connect(worker.alphaCPU.get(), &AlphaCPU::fatalError,
			this, &ExecutionCoordinator::onCPUError);

		DEBUG_LOG(QString("ExecutionCoordinator: CPU %1 worker created").arg(i));
	}

	INFO_LOG(QString("ExecutionCoordinator: %1 CPU workers created").arg(m_cpuCount));
}

void ExecutionCoordinator::destroyWorkers()
{
	INFO_LOG("ExecutionCoordinator: Destroying CPU workers");

	for (int i = 0; i < m_cpuCount; ++i) {
		auto& worker = m_workers[i];

		if (worker.thread && worker.thread->isRunning()) {
			DEBUG_LOG(QString("ExecutionCoordinator: Stopping thread for CPU %1").arg(i));

			// Request thread to quit
			worker.thread->quit();

			// Wait for thread to finish (with timeout)
			if (!worker.thread->wait(5000)) {
				WARN_LOG(QString("ExecutionCoordinator: Thread for CPU %1 did not stop, forcing").arg(i));
				worker.thread->terminate();
				worker.thread->wait();
			}
		}

		// unique_ptr auto-deletes
		worker.alphaCPU.reset();
		worker.thread.reset();

		DEBUG_LOG(QString("ExecutionCoordinator: CPU %1 worker destroyed").arg(i));
	}

	INFO_LOG("ExecutionCoordinator: All CPU workers destroyed");
}

// ============================================================================
// EXECUTION CONTROL
// ============================================================================

void ExecutionCoordinator::start()
{
	if (m_systemRunning.load()) {
		WARN_LOG("ExecutionCoordinator: System already running");
		return;
	}

	INFO_LOG("ExecutionCoordinator: Starting execution");

	// Start all worker threads
	for (int i = 0; i < m_cpuCount; ++i) {
		if (m_workers[i].thread && !m_workers[i].thread->isRunning()) {
			m_workers[i].thread->start();
			DEBUG_LOG(QString("ExecutionCoordinator: Started thread for CPU %1").arg(i));
		}
	}

	m_systemRunning.store(true);
	m_systemPaused.store(false);

	emit systemStarted();
	INFO_LOG("ExecutionCoordinator: Execution started");
}

void ExecutionCoordinator::pause()
{
	if (!m_systemRunning.load()) {
		WARN_LOG("ExecutionCoordinator: System not running, cannot pause");
		return;
	}

	INFO_LOG("ExecutionCoordinator: Pausing execution");

	// Pause all CPUs
	for (int i = 0; i < m_cpuCount; ++i) {
		pauseCPU(static_cast<CPUIdType>(i));
	}

	m_systemPaused.store(true);

	emit systemPaused();
	INFO_LOG("ExecutionCoordinator: Execution paused");
}

void ExecutionCoordinator::stop()
{
	if (!m_systemRunning.load()) {
		DEBUG_LOG("ExecutionCoordinator: System already stopped");
		return;
	}

	INFO_LOG("ExecutionCoordinator: Stopping execution");

	// Stop all CPUs
	for (int i = 0; i < m_cpuCount; ++i) {
		stopCPU(static_cast<CPUIdType>(i));
	}

	m_systemRunning.store(false);
	m_systemPaused.store(false);

	emit systemStopped();
	INFO_LOG("ExecutionCoordinator: Execution stopped");
}

void ExecutionCoordinator::reset()
{
	INFO_LOG("ExecutionCoordinator: Resetting system");

	// Stop execution
	stop();

	// Reset CPU state manager
	m_cpuStateManager.resetAllCPUs();

	// TODO: Delegate hardware reset to SSC (via globals)
	// For now, assume subsystems reset themselves

	INFO_LOG("ExecutionCoordinator: System reset complete");
}





AXP_HOT AXP_ALWAYS_INLINE void ExecutionCoordinator::pauseCPU(CPUIdType cpuId)
{
	if (!isValidCPU(cpuId)) {
		return;
	}

	DEBUG_LOG(QString("ExecutionCoordinator: Pausing CPU %1").arg(cpuId));

	if (m_workers[cpuId].alphaCPU) {
		m_workers[cpuId].alphaCPU->pause();
	}
}

AXP_HOT AXP_ALWAYS_INLINE void ExecutionCoordinator::resumeCPU(CPUIdType cpuId)
{
	if (!isValidCPU(cpuId)) {
		return;
	}

	DEBUG_LOG(QString("ExecutionCoordinator: Resuming CPU %1").arg(cpuId));

	if (m_workers[cpuId].alphaCPU) {
		m_workers[cpuId].alphaCPU->resume();
	}
}

AXP_HOT AXP_ALWAYS_INLINE void ExecutionCoordinator::stopCPU(CPUIdType cpuId)
{
	if (!isValidCPU(cpuId)) {
		return;
	}

	DEBUG_LOG(QString("ExecutionCoordinator: Stopping CPU %1").arg(cpuId));

	if (m_workers[cpuId].alphaCPU) {
		m_workers[cpuId].alphaCPU->stop();
	}
}

// ============================================================================
// IPI MANAGEMENT
// ============================================================================

bool ExecutionCoordinator::requestReschedule(CPUIdType targetCpu) noexcept
{
	if (!isValidCPU(targetCpu)) {
		return false;
	}

	// Delegate to IPI manager (uses global IRQ)
	return m_ipiManager.requestReschedule(targetCpu, &global_IRQController());
}

bool ExecutionCoordinator::requestTLBShootdown(CPUIdType targetCpu, quint64 va, quint8 asn, quint8 sizeClass) noexcept
{
	if (!isValidCPU(targetCpu)) {
		return false;
	}

	return m_ipiManager.requestTLBShootdown(targetCpu, va, asn,  &global_IRQController());
}

quint16 ExecutionCoordinator::broadcastReschedule(CPUIdType sourceCpu) noexcept
{
	if (!isValidCPU(sourceCpu)) {
		return 0;
	}

	return m_ipiManager.broadcastReschedule(sourceCpu, m_cpuCount, &global_IRQController());
}

// ============================================================================
// MEMORY ORDERING (delegates to globals)
// ============================================================================

void ExecutionCoordinator::requestGlobalMemoryBarrier(CPUIdType cpuId) noexcept
{
	if (!isValidCPU(cpuId)) {
		return;
	}

	quint16 activeCpuCount = getActiveCPUCount();
	auto& mbCoord = global_MemoryBarrierCoordinator();
	IRQController& irqCtrl = global_IRQController();

	mbCoord.requestGlobalMemoryBarrier(cpuId, activeCpuCount, &irqCtrl);
}

void ExecutionCoordinator::waitForBarrierAcknowledge(CPUIdType cpuId) noexcept
{
	auto& mbCoord = global_MemoryBarrierCoordinator();
	mbCoord.waitForBarrierAcknowledge(cpuId);
}

void ExecutionCoordinator::acknowledgeMemoryBarrier(CPUIdType cpuId) noexcept
{
	auto& mbCoord = global_MemoryBarrierCoordinator();
	mbCoord.acknowledgeMemoryBarrier(cpuId);
}

bool ExecutionCoordinator::isMemoryBarrierInProgress() const noexcept
{
	auto& mbCoord = global_MemoryBarrierCoordinator();
	return mbCoord.isMemoryBarrierInProgress();
}

void ExecutionCoordinator::drainWriteBuffers(CPUIdType cpuId) noexcept
{
	if (!isValidCPU(cpuId)) {
		return;
	}

	// Step 1: Flush CPU write buffers (via global)
	WriteBufferManager& wbMgr = global_WriteBufferManager();
	wbMgr.flushCPUWriteBuffer(cpuId);

	// Step 2: Flush MMIO pending writes (via global)
	auto& mmio = global_MMIOManager();
	mmio.flushPendingWrites(cpuId);

	// Step 3: Request CPU quiescence
	requestQuiescence(cpuId);
	waitForQuiescence(cpuId);
}

bool ExecutionCoordinator::hasPendingWrites(CPUIdType cpuId) const noexcept
{
	if (!isValidCPU(cpuId)) {
		return false;
	}

	// Check write buffer manager (via global)
	auto& wbMgr = global_WriteBufferManager();
	if (!wbMgr.isEmpty(cpuId)) {
		return true;
	}

	// Check MMIO manager (via global)
	auto& mmio = global_MMIOManager();
	if (mmio.getPendingMMIOCount(cpuId) > 0) {
		return true;
	}

	// Check CPU state manager pending stores
	if (getPendingStoreCount(cpuId) > 0) {
		return true;
	}

	return false;
}

// ============================================================================
// DIAGNOSTICS
// ============================================================================

QString ExecutionCoordinator::getSystemStatus() const noexcept
{
	QString status;
	status += QString("ExecutionCoordinator System Status:\n");
	status += QString("====================================\n");
	status += QString("CPUs: %1\n").arg(m_cpuCount);
	status += QString("System Running: %1\n").arg(m_systemRunning.load() ? "Yes" : "No");
	status += QString("System Paused: %1\n").arg(m_systemPaused.load() ? "Yes" : "No");
	status += QString("\n");

	// CPU state status
	status += m_cpuStateManager.getAllCPUStatesString();
	status += QString("\n");

	// IPI statistics
	status += m_ipiManager.getAllIPIStatistics();

	return status;
}

QString ExecutionCoordinator::getCPUStatus(CPUIdType cpuId) const noexcept
{
	if (!isValidCPU(cpuId)) {
		return QString("Invalid CPU %1").arg(cpuId);
	}

	QString status;
	status += QString("CPU %1 Status:\n").arg(cpuId);
	status += QString("==============\n");

	// Thread status
	const auto& worker = m_workers[cpuId];
	status += QString("  Thread: %1\n").arg(worker.thread ?
		(worker.thread->isRunning() ? "Running" : "Stopped") : "Not created");
	status += QString("  Worker: %1\n").arg(worker.alphaCPU ? "Present" : "Not created");

	// Execution state
	status += QString("  State: %1\n").arg(m_cpuStateManager.getCPUStateString(cpuId));
	status += QString("  Halted: %1\n").arg(isCPUHalted(cpuId) ? "Yes" : "No");
	status += QString("  Waiting: %1\n").arg(isCPUWaiting(cpuId) ? "Yes" : "No");
	status += QString("  Pending Stores: %1\n").arg(getPendingStoreCount(cpuId));

	// IPI statistics
	status += QString("\n");
	status += m_ipiManager.getIPIStatistics(cpuId);

	return status;
}

// ============================================================================
// SLOTS
// ============================================================================

void ExecutionCoordinator::onCPUHalted(CPUIdType cpuId)
{
	INFO_LOG(QString("ExecutionCoordinator: CPU %1 halted").arg(cpuId));
	m_cpuStateManager.setCPUHalted(cpuId, true);
	emit cpuHalted(cpuId);
}

void ExecutionCoordinator::onCPUError(CPUIdType cpuId, QString reason)
{
	ERROR_LOG(QString("ExecutionCoordinator: CPU %1 error: %2").arg(cpuId).arg(reason));
	emit cpuError(cpuId, reason);
}