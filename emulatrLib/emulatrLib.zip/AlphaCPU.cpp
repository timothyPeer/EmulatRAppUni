#include "AlphaCPU.h"

#define COMPONENT_NAME "AlphaCPU"
AXP_HOT AXP_FLATTEN void AlphaCPU::handleCodeModification(quint64 startPC, quint64 endPC) noexcept
{
	DEBUG_LOG(QString("AlphaCPU: Code modification detected PC=0x%1-0x%2")
		.arg(startPC, 16, 16, QChar('0'))
		.arg(endPC, 16, 16, QChar('0')));

	// Clean event creation - no direct pipeline manipulation
	m_pendingEvent.type = PendingEventType::CodeModification;
	m_pendingEvent.startPC = startPC;
	m_pendingEvent.endPC = endPC;

	// Return immediately - let runloop handle it
	DEBUG_LOG("AlphaCPU: Code modification event queued for next cycle");
}
