// ============================================================================
// SmpManager.h
// ============================================================================
// Clean SMP Manager using composition of focused components
// Single Responsibility: High-level SMP coordination
// ============================================================================

#ifndef SMPMANAGER_H
#define SMPMANAGER_H

#include <QtGlobal>
#include <QString>
#include "SubsystemCoordinator.h"
#include "../memoryLib/MemoryBarrierCoordinator.h"
#include "../coreLib/types_core.h"
#include "../cpuCoreLib/CPURegistry.h"
#include "global_ExecutionCoordinator.h"
#include "ExecutionCoordinator.h"


// Forward declarations
class AlphaCPU;
class WriteBufferManager;
class IRQController;
class GuestMemory;
class MMIOManager;
class ReservationManager;
class GrainResolver;
class PalVectorTable;
class DeviceBus;
class ScsiController;

// ============================================================================
// SMP MANAGER - High-level SMP coordination using composition
// ============================================================================

class SmpManager {
public:
	// ====================================================================
	// SINGLETON
	// ====================================================================
	static SmpManager& instance() noexcept;

	// Non-copyable
	Q_DISABLE_COPY(SmpManager)

		// ====================================================================
		// CPU MANAGEMENT (delegates to CPURegistry)
		// ====================================================================

		void addCPU(AlphaCPU* alphaCPU) noexcept { m_cpuRegistry.addCPU(alphaCPU); }
	AlphaCPU* getCPU(CPUIdType cpuId) const noexcept { return m_cpuRegistry.getCPU(cpuId); }
	quint16 getCPUCount() const noexcept { return m_cpuRegistry.getCPUCount(); }
	void setCPUCount(quint16 count) noexcept;
	bool isValidCPU(CPUIdType cpuId) const noexcept { return m_cpuRegistry.isValidCPU(cpuId); }


	AXP_HOT AXP_ALWAYS_INLINE bool isCPUHalted(CPUIdType cpuId) const noexcept {
		return global_ExecutionCoordinator().isCPUHalted(cpuId);
	}

	AXP_HOT AXP_ALWAYS_INLINE bool isCPUWaiting(CPUIdType cpuId) const noexcept {
		return global_ExecutionCoordinator().isCPUWaiting(cpuId);
	}

	AXP_HOT AXP_ALWAYS_INLINE void setCPUHalted(CPUIdType cpuId, bool halted) noexcept {
		global_ExecutionCoordinator().setCPUHalted(cpuId, halted);
	}

	AXP_HOT AXP_ALWAYS_INLINE quint16 getActiveCPUCount() const noexcept {
		return global_ExecutionCoordinator().getActiveCPUCount();
	}

	AXP_HOT AXP_ALWAYS_INLINE quint32 getPendingStoreCount(CPUIdType cpuId) const noexcept {
		return global_ExecutionCoordinator().getPendingStoreCount(cpuId);
	}

	// ====================================================================
	// SUBSYSTEM BINDING (delegates to SubsystemCoordinator)
	// ====================================================================

	void bindGuestMemory(GuestMemory* memory) noexcept;
	void bindSafeMemory(SafeMemory* mem) noexcept;
	void bindMMIOManager(MMIOManager* mmio) noexcept;
	void bindReservationManager(ReservationManager* resv) noexcept;
	void bindIRQController(IRQController* irq) noexcept;
	void bindGrainResolver(GrainResolver* grains) noexcept;
	void bindPalVectorTable(PalVectorTable* pal) noexcept;
	void bindDeviceBus(DeviceBus* devBus) noexcept;
	void bindScsiController(ScsiController* scsi) noexcept;
	void bindWriteBufferManager(WriteBufferManager* wbm) noexcept;

	// ====================================================================
	// SUBSYSTEM ACCESS (delegates to SubsystemCoordinator)
	// ====================================================================

	GuestMemory* guestMemory() const noexcept { return m_subsystemCoordinator.guestMemory(); }
	MMIOManager* mmioManager() const noexcept { return m_subsystemCoordinator.mmioManager(); }
	ReservationManager* reservationManager() const noexcept { return m_subsystemCoordinator.reservationManager(); }
	IRQController* irqController() const noexcept { return m_subsystemCoordinator.irqController(); }
	GrainResolver* grainResolver() const noexcept { return m_subsystemCoordinator.grainResolver(); }
	PalVectorTable* palVectorTable() const noexcept { return m_subsystemCoordinator.palVectorTable(); }
	DeviceBus* deviceBus() const noexcept { return m_subsystemCoordinator.deviceBus(); }
	ScsiController* scsiController() const noexcept { return m_subsystemCoordinator.scsiController(); }
	WriteBufferManager* writeBufferManager() const noexcept { return m_subsystemCoordinator.writeBufferManager(); }

	
	void waitForQuiescence(CPUIdType cpuId) noexcept {
		global_ExecutionCoordinator().waitForQuiescence(cpuId);
	}
	void requestQuiescence(CPUIdType cpuId) {
		global_ExecutionCoordinator().requestQuiescence(cpuId);
	}

	// ====================================================================
	// MEMORY BARRIER COORDINATION (complex - implemented in .cpp)
	// ====================================================================

	void requestGlobalMemoryBarrier(CPUIdType cpuId) noexcept;
	void waitForBarrierAcknowledge(CPUIdType cpuId) noexcept;
	void acknowledgeMemoryBarrier(CPUIdType cpuId) noexcept;
	bool isMemoryBarrierInProgress() const noexcept;

	// ====================================================================
	// IPI MANAGEMENT (complex - implemented in .cpp)
	// ====================================================================

	bool requestReschedule(CPUIdType targetCpu) noexcept;
	bool requestTLBShootdown(CPUIdType targetCpu, quint64 va, quint8 asn, quint8 sizeClass) noexcept;
	quint16 broadcastReschedule(CPUIdType sourceCpu) noexcept;

	// ====================================================================
	// WRITE BUFFER MANAGEMENT (complex - implemented in .cpp)
	// ====================================================================

	void drainWriteBuffers(CPUIdType cpuId) noexcept;
	bool hasPendingWrites(CPUIdType cpuId) const noexcept;
	bool hasPendingIPI(CPUIdType cpuId) const noexcept;
	QString getMemoryOrderingStatus(CPUIdType cpuId) const noexcept;

	// ====================================================================
	// DIAGNOSTICS AND STATUS (complex - implemented in .cpp)
	// ====================================================================

	QString getSystemStatus() const noexcept;
	QString getCPUStatus(CPUIdType cpuId) const noexcept;
	QString getSubsystemStatus() const noexcept;

	// ====================================================================
	// LEGACY COMPATIBILITY
	// ====================================================================

	AlphaCPU* getAlphaCpu(CPUIdType cpuId) const noexcept { return getCPU(cpuId); }
	GuestMemory* safeMemory() const noexcept { return guestMemory(); }
	PalVectorTable* palVectors() const noexcept { return palVectorTable(); }

	// ====================================================================
	// COMPONENT ACCESS (for advanced usage)
	// ====================================================================

	CPURegistry& cpuRegistry() noexcept { return m_cpuRegistry; }
	SubsystemCoordinator& subsystemCoordinator() noexcept { return m_subsystemCoordinator; }
	MemoryBarrierCoordinator& memoryBarrierCoordinator() noexcept { return m_memoryBarrierCoordinator; }


private:
	// Private constructor for singleton
	SmpManager() noexcept;
	~SmpManager() = default;

	// Composed components (each with single responsibility)
	CPURegistry m_cpuRegistry;
	SubsystemCoordinator m_subsystemCoordinator;

	MemoryBarrierCoordinator m_memoryBarrierCoordinator;


	// Helper methods
	void initializeComponents() noexcept;
	void logSystemInitialization() noexcept;
};

#endif // SMPMANAGER_H