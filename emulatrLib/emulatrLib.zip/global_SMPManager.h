#ifndef GLOBAL_SMPMANAGER_H
#define GLOBAL_SMPMANAGER_H

// Forward declaration
class SmpManager;

// Global accessor function - must match .cpp!
SmpManager& global_SMPManager() noexcept;

#endif // GLOBAL_SMPMANAGER_H