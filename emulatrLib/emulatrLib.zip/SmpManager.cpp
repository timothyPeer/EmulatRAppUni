// ============================================================================
// SmpManager.cpp
// ============================================================================
// SMP Manager implementation - complex methods only
// Simple delegations are inline in the header
// ============================================================================

#include "SmpManager.h"
#include "../coreLib/LoggingMacros.h"
#include "../cpuCoreLib/AlphaCPU.h"
#include "../memoryLib/WriteBufferManager.h"
#include "../memoryLib/GuestMemory.h"
#include "../memoryLib/SafeMemory.h"
#include "../mmioLib/MMIO_Manager.h"
#include "../cpuCoreLib/ReservationManager.h"
#include "../coreLib/IRQController.h"
#include "../grainFactoryLib/GrainResolver.h"
#include "../palLib_EV6/PalVectorTable_final.h"

// ============================================================================
// SINGLETON
// ============================================================================

SmpManager& SmpManager::instance() noexcept {
	static SmpManager singleton;
	return singleton;
}

// ============================================================================
// CONSTRUCTOR
// ============================================================================

SmpManager::SmpManager() noexcept
{
	initializeComponents();
	logSystemInitialization();
}

// ============================================================================
// CPU MANAGEMENT
// ============================================================================

void SmpManager::setCPUCount(quint16 count) noexcept {
	m_cpuRegistry.setCPUCount(count);
}

// ============================================================================
// SUBSYSTEM BINDING
// ============================================================================

void SmpManager::bindGuestMemory(GuestMemory* mem) noexcept {
	m_subsystemCoordinator.bindGuestMemory(mem);
}

void SmpManager::bindSafeMemory(SafeMemory* mem) noexcept {
	m_subsystemCoordinator.bindSafeMemory(mem);
}

void SmpManager::bindMMIOManager(MMIOManager* mmio) noexcept {
	m_subsystemCoordinator.bindMMIOManager(mmio);
}

void SmpManager::bindReservationManager(ReservationManager* resv) noexcept {
	m_subsystemCoordinator.bindReservationManager(resv);
}

void SmpManager::bindIRQController(IRQController* irq) noexcept {
	m_subsystemCoordinator.bindIRQController(irq);
}

void SmpManager::bindGrainResolver(GrainResolver* grains) noexcept {
	m_subsystemCoordinator.bindGrainResolver(grains);
}

void SmpManager::bindPalVectorTable(PalVectorTable* pal) noexcept {
	m_subsystemCoordinator.bindPalVectorTable(pal);
}

void SmpManager::bindDeviceBus(DeviceBus* devBus) noexcept {
	m_subsystemCoordinator.bindDeviceBus(devBus);
}

void SmpManager::bindScsiController(ScsiController* scsi) noexcept {
	m_subsystemCoordinator.bindScsiController(scsi);
}

void SmpManager::bindWriteBufferManager(WriteBufferManager* wbm) noexcept {
	m_subsystemCoordinator.bindWriteBufferManager(wbm);
}

// ============================================================================
// MEMORY BARRIER COORDINATION
// ============================================================================

void SmpManager::requestGlobalMemoryBarrier(CPUIdType cpuId) noexcept
{
	quint16 activeCpuCount = getActiveCPUCount();
	IRQController* irqCtrl = irqController();
	m_memoryBarrierCoordinator.requestGlobalMemoryBarrier(cpuId, activeCpuCount, irqCtrl);
}

void SmpManager::waitForBarrierAcknowledge(CPUIdType cpuId) noexcept
{
	m_memoryBarrierCoordinator.waitForBarrierAcknowledge(cpuId);
}

void SmpManager::acknowledgeMemoryBarrier(CPUIdType cpuId) noexcept
{
	m_memoryBarrierCoordinator.acknowledgeMemoryBarrier(cpuId);
}

bool SmpManager::isMemoryBarrierInProgress() const noexcept
{
	return m_memoryBarrierCoordinator.isMemoryBarrierInProgress();
}

// ============================================================================
// IPI MANAGEMENT
// ============================================================================

bool SmpManager::requestReschedule(CPUIdType targetCpu) noexcept
{
	IRQController* irqCtrl = irqController();
	return global_ExecutionCoordinator().requestReschedule(targetCpu);
}

bool SmpManager::requestTLBShootdown(CPUIdType targetCpu, quint64 va, quint8 asn, quint8 sizeClass) noexcept
{
	IRQController* irqCtrl = irqController();
	return global_ExecutionCoordinator().requestTLBShootdown(targetCpu, va, asn, sizeClass);
}

quint16 SmpManager::broadcastReschedule(CPUIdType sourceCpu) noexcept
{
	quint16 cpuCount = getCPUCount();
	IRQController* irqCtrl = irqController();
	return global_ExecutionCoordinator().broadcastReschedule(sourceCpu);
}

// ============================================================================
// WRITE BUFFER MANAGEMENT
// ============================================================================

void SmpManager::drainWriteBuffers(CPUIdType cpuId) noexcept
{
	if (!isValidCPU(cpuId)) {
		return;
	}

	// Step 1: Flush CPU write buffers
	WriteBufferManager* wbMgr = writeBufferManager();
	if (wbMgr) {
		wbMgr->flushCPUWriteBuffer(cpuId);
	}

	// Step 2: Flush MMIO pending writes
	MMIOManager* mmio = mmioManager();
	if (mmio) {
		mmio->flushPendingWrites(cpuId);
	}

	// Step 3: Request CPU quiescence
	requestQuiescence(cpuId);
	waitForQuiescence(cpuId);
}

bool SmpManager::hasPendingWrites(CPUIdType cpuId) const noexcept
{
	if (!isValidCPU(cpuId)) {
		return false;
	}

	// Check write buffer manager
	WriteBufferManager* wbMgr = writeBufferManager();
	if (wbMgr && !wbMgr->isEmpty(cpuId)) {
		return true;
	}

	// Check MMIO manager
	MMIOManager* mmio = mmioManager();
	if (mmio && mmio->getPendingMMIOCount(cpuId) > 0) {
		return true;
	}

	// Check CPU state manager pending stores
	if (getPendingStoreCount(cpuId) > 0) {
		return true;
	}
	return false;

}

bool SmpManager::hasPendingIPI(CPUIdType cpuId) const noexcept
{
	// Check IPI mailbox state
	// Implementation depends on your IPI architecture
	return false; // Placeholder
}

QString SmpManager::getMemoryOrderingStatus(CPUIdType cpuId) const noexcept
{
	if (!isValidCPU(cpuId)) {
		return QString("Invalid CPU %1").arg(cpuId);
	}

	QString status;
	status += QString("Memory Ordering Status for CPU %1:\n").arg(cpuId);

	// Write buffer status
	WriteBufferManager* wbMgr = writeBufferManager();
	if (wbMgr) {
		quint32 pendingWrites = wbMgr->getPendingCount(cpuId);
		status += QString("  Write Buffer: %1 pending\n").arg(pendingWrites);
	}
	else {
		status += QString("  Write Buffer: Not available\n");
	}

	// MMIO status
	MMIOManager* mmio = mmioManager();
	if (mmio) {
		quint32 pendingMMIO = mmio->getPendingMMIOCount(cpuId);
		status += QString("  MMIO: %1 pending\n").arg(pendingMMIO);
	}
	else {
		status += QString("  MMIO: Not available\n");
	}

	// CPU state
	status += QString("  CPU State: %1\n").arg(global_ExecutionCoordinator().getCPUStateString(cpuId));
	status += QString("  Pending Stores: %1\n").arg(getPendingStoreCount(cpuId));

	// Memory barrier status
	status += QString("  Memory Barrier: %1\n").arg(isMemoryBarrierInProgress() ? "In Progress" : "None");

	return status;
}

// ============================================================================
// DIAGNOSTICS AND STATUS
// ============================================================================

QString SmpManager::getSystemStatus() const noexcept
{
	QString status;
	status += QString("SmpManager System Status:\n");
	status += QString("=========================\n");

	// CPU registry status
	status += m_cpuRegistry.getRegistryStatus();
	status += QString("\n");

	// Subsystem status
	status += m_subsystemCoordinator.getSubsystemStatus();
	status += QString("\n");

	// CPU state status
	status += global_ExecutionCoordinator().getAllCPUStatesString();
	status += QString("\n");

	// Memory barrier status
	status += m_memoryBarrierCoordinator.getBarrierStatus();
	status += QString("\n");

	// IPI statistics
	status += global_ExecutionCoordinator().getAllIPIStatistics();

	return status;
}

QString SmpManager::getCPUStatus(CPUIdType cpuId) const noexcept
{
	if (!isValidCPU(cpuId)) {
		return QString("Invalid CPU %1").arg(cpuId);
	}

	QString status;
	status += QString("CPU %1 Status:\n").arg(cpuId);
	status += QString("==============\n");

	// Basic CPU info
	AlphaCPU* cpu = getCPU(cpuId);
	status += QString("  CPU Object: %1\n").arg(cpu ? "Present" : "Not registered");
	status += QString("  State: %1\n").arg(global_ExecutionCoordinator().getCPUStateString(cpuId));
	status += QString("  Halted: %1\n").arg(isCPUHalted(cpuId) ? "Yes" : "No");
	status += QString("  Waiting: %1\n").arg(isCPUWaiting(cpuId) ? "Yes" : "No");
	status += QString("  Pending Stores: %1\n").arg(getPendingStoreCount(cpuId));

	// Memory ordering status
	status += QString("\n");
	status += getMemoryOrderingStatus(cpuId);

	// IPI statistics
	status += QString("\n");
	status += global_ExecutionCoordinator().getIPIStatistics(cpuId);

	return status;
}

QString SmpManager::getSubsystemStatus() const noexcept
{
	return m_subsystemCoordinator.getSubsystemStatus();
}

// ============================================================================
// PRIVATE HELPERS
// ============================================================================

void SmpManager::initializeComponents() noexcept
{
	// Components are initialized in their constructors
	// Additional cross-component initialization can be added here if needed
}

void SmpManager::logSystemInitialization() noexcept
{
	// Log subsystem status
	if (m_subsystemCoordinator.areAllSubsystemsBound()) {
		INFO_LOG("SmpManager: All critical subsystems bound and ready");
	}
	else {
		WARN_LOG("SmpManager: Some critical subsystems not bound");
	}
}